import React, { useEffect, useRef } from "react";

import { ApryseLicenseKey } from "../../../consts";
import { IDocumentRendererProps } from "./types";
import WebViewer from "@pdftron/webviewer";
import styles from "./DocumentRenderers.module.scss";

export default function ApryseRenderer({ fileData, fileName }: IDocumentRendererProps) {
  const viewer = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!viewer.current) {
      return;
    }

    WebViewer(
      {
        disabledElements: ["contextMenuPopup", "ribbons", "menuButton", "selectToolButton", "textPopup", "toolsHeader"],
        fullAPI: true,
        licenseKey: ApryseLicenseKey,
        path: "webviewer",
      },
      viewer.current
    )
      .then((instance) => {
        var FitMode = instance.UI.FitMode;
        const blob = new Blob([fileData]);
        instance.UI.setFitMode(FitMode.FitWidth);
        instance.UI.loadDocument(blob, { filename: fileName });
      })
      .catch((err: unknown) => {
        if (err instanceof Error) {
          console.log(err);
        }
      });
  }, [fileData, fileName]);

  return <div ref={viewer} className={styles.apryse} />;
}
ApryseRenderer.fileTypes = [
  "bmp",
  "doc",
  "docx",
  "gif",
  "jfif",
  "jpeg",
  "jpg",
  "pdf",
  "png",
  "ppt",
  "pptx",
  "tiff",
  "xls",
  "xlsx",
  // // audio
  // 'mp3',
  // 'wav',
  // 'ogg',
  // 'flac',
  // // video
  // 'mp4',
  // 'ogg',
  // 'webm'
];
